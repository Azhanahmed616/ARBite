import { motion } from "framer-motion";
import { LeadModal } from "@/components/LeadModal";
import { Button } from "@/components/ui/button";
import { 
  Smartphone, 
  Utensils, 
  Clock, 
  TrendingUp, 
  ScanLine, 
  Layers, 
  CheckCircle2, 
  ArrowRight,
  Menu,
  ChefHat
} from "lucide-react";

// Animation variants
const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Home() {
  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-white/5">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <ScanLine className="text-primary-foreground w-5 h-5" />
            </div>
            <span className="text-xl font-display font-bold tracking-tight">ARBite</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#features" className="hover:text-primary transition-colors">Features</a>
            <a href="#how-it-works" className="hover:text-primary transition-colors">How it Works</a>
            <a href="#pricing" className="hover:text-primary transition-colors">Pricing</a>
          </div>
          <LeadModal>
            <Button size="sm" className="font-semibold bg-primary text-primary-foreground hover:bg-primary/90">
              Get Started
            </Button>
          </LeadModal>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        {/* Abstract Background Blobs */}
        <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[500px] h-[500px] bg-accent/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial="initial"
              animate="animate"
              variants={staggerContainer}
              className="space-y-8"
            >
              <motion.div variants={fadeIn} className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-primary text-sm font-medium">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                The Future of Dining is Here
              </motion.div>
              
              <motion.h1 variants={fadeIn} className="text-5xl lg:text-7xl font-display font-bold leading-tight">
                Menus That <br/>
                <span className="text-gradient">Come to Life</span>
              </motion.h1>
              
              <motion.p variants={fadeIn} className="text-xl text-muted-foreground max-w-lg leading-relaxed">
                Stop guessing. Start craving. Let your customers visualize their meal in stunning 3D augmented reality before they order.
              </motion.p>
              
              <motion.div variants={fadeIn} className="flex flex-col sm:flex-row gap-4">
                <LeadModal>
                  <Button size="lg" className="text-lg px-8 py-6 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all">
                    Book a Free Demo
                  </Button>
                </LeadModal>
                <Button size="lg" variant="outline" className="text-lg px-8 py-6 rounded-xl border-white/10 hover:bg-white/5">
                  See How It Works
                </Button>
              </motion.div>
              
              <motion.div variants={fadeIn} className="pt-8 flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex -space-x-3">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-background bg-zinc-800 flex items-center justify-center text-xs">
                      {String.fromCharCode(64+i)}
                    </div>
                  ))}
                </div>
                <p>Trusted by 100+ modern restaurants</p>
              </motion.div>
            </motion.div>

            {/* Visual */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative lg:h-[600px] flex items-center justify-center"
            >
              <div className="relative z-10 w-[300px] h-[600px] bg-black rounded-[40px] border-[8px] border-zinc-800 shadow-2xl shadow-primary/20 overflow-hidden">
                {/* Simulated Phone Screen */}
                <div className="absolute inset-0 bg-zinc-900">
                  {/* Camera View Placeholder */}
                  <img 
                    src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80" 
                    alt="Salad Bowl"
                    className="w-full h-full object-cover opacity-80" 
                  />
                  
                  {/* AR Overlay UI */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-2 border-primary/50 rounded-lg animate-pulse flex items-center justify-center">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                  </div>
                  
                  {/* Floating AR Card */}
                  <motion.div 
                    animate={{ y: [0, -10, 0] }}
                    transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                    className="absolute bottom-8 left-4 right-4 bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-xl"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-white">Superfood Salad</h4>
                        <p className="text-xs text-white/70">450 kcal • Gluten Free</p>
                      </div>
                      <span className="font-bold text-primary">$18.00</span>
                    </div>
                    <Button size="sm" className="w-full mt-3 bg-primary text-primary-foreground h-8 text-xs font-bold">
                      Add to Order
                    </Button>
                  </motion.div>
                </div>
              </div>
              
              {/* Decorative Elements around phone */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border border-white/5 rounded-full animate-[spin_20s_linear_infinite]" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] border border-white/10 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-24 bg-zinc-900/50 border-y border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Traditional Menus Are <br /><span className="text-destructive">Holding You Back</span></h2>
            <p className="text-muted-foreground text-lg">Static paper menus fail to capture the essence of your culinary creations.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: <Menu className="w-8 h-8 text-destructive" />, title: "Can't Visualize", desc: "Customers struggle to imagine the dish from just text." },
              { icon: <ChefHat className="w-8 h-8 text-destructive" />, title: "Order Anxiety", desc: "Fear of ordering something they won't like leads to safe, cheap choices." },
              { icon: <Clock className="w-8 h-8 text-destructive" />, title: "Slow Decisions", desc: "More questions for waiters means slower table turnover." },
              { icon: <Layers className="w-8 h-8 text-destructive" />, title: "Static Content", desc: "Can't easily update for sold-out items or daily specials." }
            ].map((item, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="bg-background border border-white/5 p-8 rounded-2xl hover:border-destructive/50 transition-colors"
              >
                <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center mb-6">
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section id="how-it-works" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background to-secondary/50 pointer-events-none" />
        <div className="container mx-auto px-4 relative">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Upgrade to <span className="text-primary">AR Menus</span></h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">No app download required. Just seamless, instant 3D visualization right in the browser.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 relative">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-12 left-[16%] right-[16%] h-0.5 bg-gradient-to-r from-transparent via-primary/50 to-transparent border-t border-dashed border-white/20" />

            {[
              { number: "01", title: "Place QR Code", desc: "We provide elegant QR stands for your tables." },
              { number: "02", title: "Scan & View", desc: "Customers scan with their default camera app." },
              { number: "03", title: "Order Confidently", desc: "They see the dish in AR and order instantly." }
            ].map((step, i) => (
              <div key={i} className="relative flex flex-col items-center text-center">
                <div className="w-24 h-24 rounded-2xl bg-secondary border border-white/10 flex items-center justify-center mb-6 relative z-10 shadow-xl shadow-black/20">
                  <span className="text-3xl font-display font-bold text-primary">{step.number}</span>
                </div>
                <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="features" className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4">
           <div className="grid lg:grid-cols-2 gap-16 items-center">
             <div>
                <h2 className="text-3xl md:text-4xl font-display font-bold mb-8 leading-tight">
                  Why Top Restaurants <br/>
                  Are <span className="text-accent">Switching to AR</span>
                </h2>
                
                <div className="space-y-6">
                  {[
                    { title: "30% Higher Engagement", desc: "Customers spend more time exploring your menu." },
                    { title: "20% Faster Table Turnover", desc: "Visuals help guests decide quicker." },
                    { title: "Fewer Returned Dishes", desc: "What they see is exactly what they get." },
                    { title: "Premium Brand Perception", desc: "Position your venue as a modern, forward-thinking establishment." }
                  ].map((benefit, i) => (
                    <div key={i} className="flex gap-4">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 text-accent flex items-center justify-center mt-1">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-lg font-bold mb-1">{benefit.title}</h4>
                        <p className="text-muted-foreground text-sm">{benefit.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-10">
                  <LeadModal>
                    <Button className="bg-white text-black hover:bg-white/90 font-bold px-8">
                      Start Your Transformation
                    </Button>
                  </LeadModal>
                </div>
             </div>

             <div className="relative">
               <div className="grid grid-cols-2 gap-4">
                 <img 
                   src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&q=80" 
                   className="rounded-2xl object-cover h-64 w-full translate-y-8 shadow-2xl" 
                   alt="Restaurant Interior" 
                 />
                 <img 
                   src="https://images.unsplash.com/photo-1552566626-52f8b828add9?w=600&q=80" 
                   className="rounded-2xl object-cover h-64 w-full shadow-2xl" 
                   alt="Plated Food" 
                 />
               </div>
               {/* Floating Badge */}
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-background/90 backdrop-blur-xl border border-white/10 p-6 rounded-2xl shadow-2xl text-center">
                 <p className="text-4xl font-display font-bold text-primary mb-1">35%</p>
                 <p className="text-sm font-medium text-muted-foreground">Increase in Dessert Sales</p>
               </div>
             </div>
           </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-muted-foreground text-lg">Choose the plan that fits your venue size.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Starter */}
            <div className="bg-background border border-white/5 rounded-2xl p-8 hover:border-white/10 transition-all">
              <h3 className="text-xl font-bold mb-2">Starter AR</h3>
              <p className="text-muted-foreground mb-6 text-sm">Perfect for cafes and small bistros.</p>
              <div className="mb-8">
                <span className="text-muted-foreground text-sm">Starting from</span>
                <div className="text-3xl font-bold text-white">PKR 15,000<span className="text-base font-normal text-muted-foreground">/mo</span></div>
              </div>
              <ul className="space-y-4 mb-8 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-white/50" /> Up to 10 AR Dishes</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-white/50" /> Basic Analytics</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-white/50" /> Email Support</li>
              </ul>
              <LeadModal>
                <Button variant="outline" className="w-full">Contact Sales</Button>
              </LeadModal>
            </div>

            {/* Growth */}
            <div className="relative bg-white/5 border border-primary/50 rounded-2xl p-8 transform md:-translate-y-4 shadow-2xl shadow-primary/10">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Most Popular</div>
              <h3 className="text-xl font-bold mb-2 text-primary">Growth</h3>
              <p className="text-white/70 mb-6 text-sm">For busy restaurants needing impact.</p>
              <div className="mb-8">
                <span className="text-white/70 text-sm">Starting from</span>
                <div className="text-3xl font-bold text-white">PKR 35,000<span className="text-base font-normal text-white/50">/mo</span></div>
              </div>
              <ul className="space-y-4 mb-8 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Up to 30 AR Dishes</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Advanced Analytics</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Priority Support</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> QR Stand Design</li>
              </ul>
              <LeadModal>
                <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-bold">Get Started</Button>
              </LeadModal>
            </div>

            {/* Pro */}
            <div className="bg-background border border-white/5 rounded-2xl p-8 hover:border-white/10 transition-all">
              <h3 className="text-xl font-bold mb-2">Enterprise</h3>
              <p className="text-muted-foreground mb-6 text-sm">Multi-location chains & franchises.</p>
              <div className="mb-8">
                <span className="text-muted-foreground text-sm">Custom Quote</span>
                <div className="text-3xl font-bold text-white">Contact Us</div>
              </div>
              <ul className="space-y-4 mb-8 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-white/50" /> Unlimited AR Dishes</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-white/50" /> Custom Integration</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-white/50" /> Dedicated Account Manager</li>
              </ul>
              <LeadModal>
                <Button variant="outline" className="w-full">Contact Sales</Button>
              </LeadModal>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof / Trusted By */}
      <section className="py-20 border-t border-white/5">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-10">Trusted by innovative venues</p>
          <div className="flex flex-wrap justify-center items-center gap-12 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
             {/* Placeholder Logos using Text */}
             <span className="text-2xl font-display font-black tracking-tighter">GRILLHOUSE</span>
             <span className="text-2xl font-serif italic font-bold">La Bella</span>
             <span className="text-2xl font-sans font-extrabold tracking-wide border-2 border-current px-2">URBAN</span>
             <span className="text-2xl font-mono font-bold">SUSHIKO</span>
             <span className="text-2xl font-display font-bold">BURGER<span className="text-primary">LAB</span></span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-white/10 py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-12">
            <div>
              <h2 className="text-3xl font-display font-bold mb-2">See It Before Your Customers Do</h2>
              <p className="text-muted-foreground">Join the AR revolution in dining today.</p>
            </div>
            <LeadModal>
              <Button size="lg" className="bg-white text-black hover:bg-white/90 font-bold px-8">
                Book a Free Demo
              </Button>
            </LeadModal>
          </div>
          
          <div className="h-px w-full bg-white/10 mb-8" />
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <ScanLine className="w-4 h-4 text-primary" />
              <span className="font-bold text-white">ARBite</span>
              <span>© 2024</span>
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
