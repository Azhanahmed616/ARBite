## Packages
framer-motion | Complex scroll animations and transitions for the landing page
react-hook-form | Form state management
@hookform/resolvers | Zod integration for react-hook-form

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
